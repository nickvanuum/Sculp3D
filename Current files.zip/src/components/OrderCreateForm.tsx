"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { BUST_TIERS, priceForHeightMm } from "@/lib/pricing";

type StyleKey = "classical" | "modern" | "custom";

export default function CreateOrderForm() {
  const router = useRouter();

  // form state
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [heightMm, setHeightMm] = useState<number>(150);
  const [style, setStyle] = useState<StyleKey>("classical");
  const [styleHint, setStyleHint] = useState("");
  const [notes, setNotes] = useState("");
  const [consent, setConsent] = useState(false);
  const [image, setImage] = useState<File | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const price = useMemo(() => priceForHeightMm(Number(heightMm || 0)), [heightMm]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!email.trim()) return setError("Please enter your email.");
    if (!image) return setError("Please upload exactly 1 photo.");
    if (!consent) return setError("Please confirm you have permission to use this photo.");
    if (!heightMm || Number.isNaN(Number(heightMm))) return setError("Please choose a valid bust height.");

    setLoading(true);
    try {
      const fd = new FormData();
      fd.append("email", email.trim());
      fd.append("phone", phone.trim()); // safe even if backend ignores it
      fd.append("bustSize", String(heightMm)); // your API uses bustSize
      fd.append("style", style);
      fd.append("styleHint", styleHint.trim());
      fd.append("notes", notes.trim());
      fd.append("images", image);

      const res = await fetch("/api/orders", { method: "POST", body: fd });
      const json = await res.json().catch(() => ({}));

      if (!res.ok) {
        setError(json?.error ?? "Failed to create order.");
        setLoading(false);
        return;
      }

      const orderId = String(json.orderId || "");
      if (!orderId) {
        setError("Order created, but no orderId was returned.");
        setLoading(false);
        return;
      }

      router.push(`/order/${orderId}`);
    } catch (err: any) {
      setError(err?.message ?? "Network error");
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Email + phone */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="text-sm font-semibold text-slate-900">Email</label>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
            className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm focus-ring"
          />
        </div>

        <div>
          <label className="text-sm font-semibold text-slate-900">Phone (optional)</label>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+31 6 1234 5678"
            className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm focus-ring"
          />
          <p className="mt-1 text-xs text-slate-500">
            Only used for delivery questions.
          </p>
        </div>
      </div>

      {/* Bust height tiers */}
      <div>
        <div className="flex items-end justify-between gap-4">
          <label className="text-sm font-semibold text-slate-900">Bust height</label>
          <p className="text-xs text-slate-500">Base → top</p>
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          {BUST_TIERS.map((t) => {
            const selected = Number(heightMm) === t.heightMm;
            return (
              <button
                key={t.heightMm}
                type="button"
                onClick={() => setHeightMm(t.heightMm)}
                className={[
                  "rounded-2xl border px-4 py-3 text-left shadow-sm transition",
                  selected
                    ? "border-slate-900 bg-white ring-2 ring-slate-900/10"
                    : "border-slate-200 bg-white hover:bg-slate-50",
                ].join(" ")}
              >
                <p className="text-sm font-semibold text-slate-900">{t.label}</p>
                <p className="mt-1 text-xs text-slate-500">{t.subtitle ?? ""}</p>
                <p className="mt-2 text-xs font-semibold text-slate-900">€{t.priceEur}</p>
              </button>
            );
          })}
        </div>

        {/* Optional custom height input */}
        <div className="mt-3 flex items-center gap-3">
          <label className="text-xs text-slate-500">Custom height (mm)</label>
          <input
            type="number"
            value={heightMm}
            onChange={(e) => setHeightMm(Number(e.target.value))}
            className="w-32 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm focus-ring"
            min={80}
            max={260}
          />
          <p className="text-xs text-slate-500">Estimated price: <span className="font-semibold text-slate-900">€{price}</span></p>
        </div>
      </div>

      {/* Style choices */}
      <div>
        <label className="text-sm font-semibold text-slate-900">Style</label>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          {[
            { key: "classical", title: "Classical", desc: "Marble look", icon: "/icons/bust.svg" },
            { key: "modern", title: "Modern", desc: "Clean studio", icon: "/icons/mesh.svg" },
            { key: "custom", title: "Custom", desc: "Your vibe", icon: "/icons/camera.svg" },
          ].map((s) => {
            const selected = style === (s.key as StyleKey);
            return (
              <button
                key={s.key}
                type="button"
                onClick={() => setStyle(s.key as StyleKey)}
                className={[
                  "rounded-2xl border px-4 py-3 text-left shadow-sm transition",
                  selected
                    ? "border-slate-900 bg-white ring-2 ring-slate-900/10"
                    : "border-slate-200 bg-white hover:bg-slate-50",
                ].join(" ")}
              >
                <div className="flex items-center gap-2">
                  <Image src={s.icon} alt="" width={18} height={18} />
                  <p className="text-sm font-semibold text-slate-900">{s.title}</p>
                </div>
                <p className="mt-1 text-xs text-slate-500">{s.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <label className="text-sm font-semibold text-slate-900">Style hint (optional)</label>
        <input
          value={styleHint}
          onChange={(e) => setStyleHint(e.target.value)}
          placeholder='e.g. "slightly more heroic", "cleaner hair shape"'
          className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm focus-ring"
        />
      </div>

      <div>
        <label className="text-sm font-semibold text-slate-900">Notes (optional)</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Anything you want us to know"
          rows={3}
          className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm focus-ring"
        />
      </div>

      {/* Upload */}
      <div>
        <label className="text-sm font-semibold text-slate-900">Upload 1 photo (3/4 angle)</label>
        <input
          type="file"
          accept="image/*"
          className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm focus-ring"
          onChange={(e) => {
            const f = e.target.files?.[0] ?? null;
            setImage(f);
          }}
        />
        <p className="mt-1 text-xs text-slate-500">
          Exactly 1 image. Sharp face, front lighting, no heavy filters.
        </p>
      </div>

      {/* Consent */}
      <label className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4 text-sm">
        <input
          type="checkbox"
          checked={consent}
          onChange={(e) => setConsent(e.target.checked)}
          className="mt-1 h-4 w-4"
        />
        <span className="text-slate-700">
          I confirm I have permission to use this photo to generate a 3D preview and produce a bust print.
        </span>
      </label>

      {/* Price + submit */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold text-slate-900">Estimated price</p>
          <p className="text-lg font-semibold text-slate-900">€{price}</p>
        </div>
        <p className="mt-1 text-xs text-slate-500">
          Final price is confirmed at checkout after preview approval.
        </p>

        {error ? (
          <p className="mt-3 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-800">
            {error}
          </p>
        ) : null}

        <button
          type="submit"
          disabled={loading}
          className="mt-4 inline-flex w-full items-center justify-center rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white shadow-sm hover:bg-slate-800 disabled:opacity-60 focus-ring"
        >
          {loading ? "Creating order..." : "Create bust preview"}
        </button>
      </div>
    </form>
  );
}
