"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { FilamentSelector, type FilamentId } from "@/components/FilamentSelector";

type Props = {
  orderId: string;
  initialStatus: string;
};

type StatusResponse = {
  order?: {
    id: string;
    status: string;
    preview_attempts: number;
    retry_credits: number;
    generation_started_at?: string | null;

    clayPreviewUrl?: string | null;
    modelGlbUrl?: string | null;
    modelObjUrl?: string | null;

    filament_color?: string | null;
    hq?: boolean;
  };
  progress?: number | null;
  stage?: "clay_preview" | "model" | null;
  message?: string | null;
  paymentLocked?: boolean;
  error?: string;
  details?: string;
};

const FREE_ATTEMPTS = 2;

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

export function OrderLivePreview({ orderId, initialStatus }: Props) {
  const [status, setStatus] = useState<string>(initialStatus || "created");
  const [attempts, setAttempts] = useState<number>(0);
  const [credits, setCredits] = useState<number>(0);

  const [stage, setStage] = useState<"clay_preview" | "model" | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const [clayPreviewUrl, setClayPreviewUrl] = useState<string | null>(null);
  const [modelGlbUrl, setModelGlbUrl] = useState<string | null>(null);
  const [modelObjUrl, setModelObjUrl] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [uiMsg, setUiMsg] = useState<string | null>(null);

  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const startedAtRef = useRef<number | null>(null);

  // 3D viewer
  const [show3D, setShow3D] = useState(false);
  const viewerTopRef = useRef<HTMLDivElement | null>(null);

  // Mount guard for <model-viewer>
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  // Filament choice (required before paying)
  const [filament, setFilament] = useState<FilamentId | null>(null);

  // Tick clock (only for elapsed)
  useEffect(() => {
    if (status !== "processing") return;
    const t = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(t);
  }, [status]);

  const freeRemaining = useMemo(() => Math.max(0, FREE_ATTEMPTS - attempts), [attempts]);

  const stageLabel = useMemo(() => {
    if (stage === "clay_preview") return "Preview image";
    if (stage === "model") return "3D model";
    return null;
  }, [stage]);

  const elapsedSec = useMemo(() => {
    const t0 = startedAtRef.current;
    if (!t0) return 0;
    return Math.max(0, Math.floor((nowMs - t0) / 1000));
  }, [nowMs]);

  const statusText = useMemo(() => {
    if (status === "paid") return "Paid ✅";
    if (status === "preview_ready") return "Preview ready";
    if (status === "processing") return "Generating…";
    if (status === "failed") return "Failed";
    return status || "unknown";
  }, [status]);

  const canRetry = status === "preview_ready";

  // Approve & pay only when preview_ready AND filament selected (unless already paid)
  const canPay = (status === "preview_ready" || status === "paid") && (status === "paid" || !!filament);

  // 3D exists only after paid
  const canShow3D = status === "paid" && !!modelGlbUrl;

  async function refresh() {
    const res = await fetch(`/api/orders/status?orderId=${encodeURIComponent(orderId)}`, {
      cache: "no-store",
    });

    const json: StatusResponse = await res.json().catch(() => ({}));

    if (!res.ok || json.error) {
      setUiMsg((prev) => prev ?? json?.error ?? "Could not load order status.");
      return;
    }

    const o = json.order;
    if (!o) {
      setUiMsg((prev) => prev ?? "Order not found.");
      return;
    }

    setUiMsg(null);

    setStatus(String(o.status ?? ""));
    setAttempts(Number(o.preview_attempts ?? 0));
    setCredits(Number(o.retry_credits ?? 0));

    setStage(json.stage ?? null);
    setMessage(json.message ?? null);

    setClayPreviewUrl(o.clayPreviewUrl ?? null);
    setModelGlbUrl(o.modelGlbUrl ?? null);
    setModelObjUrl(o.modelObjUrl ?? null);

    // If DB already has filament_color, preload it into UI once
    const dbFilament = (o.filament_color ?? null) as FilamentId | null;
    if (dbFilament && !filament) setFilament(dbFilament);

    if (o.generation_started_at) {
      const t = Date.parse(o.generation_started_at);
      if (Number.isFinite(t)) startedAtRef.current = t;
    }

    if (String(o.status) === "processing" && !startedAtRef.current) {
      startedAtRef.current = Date.now();
    }

    if (String(o.status) !== "paid") setShow3D(false);
  }

  // Recommended polling:
  // - processing: 2.5s
  // - preview_ready: 10s
  // - paid: 5s until model arrives
  useEffect(() => {
    let intervalMs = 15000;

    if (status === "processing") intervalMs = 2500;
    else if (status === "preview_ready") intervalMs = 10000;
    else if (status === "paid" && !modelGlbUrl) intervalMs = 5000;

    const t = setInterval(refresh, intervalMs);
    refresh();

    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, orderId, modelGlbUrl]);

  async function retry() {
    setUiMsg(null);
    setLoading(true);
    try {
      const res = await fetch("/api/orders/retry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId }),
      });

      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        setUiMsg(json?.error ?? "Retry failed.");
        setLoading(false);
        return;
      }

      startedAtRef.current = Date.now();
      setStatus("processing");
      setShow3D(false);
      setLoading(false);
    } catch (e: any) {
      setUiMsg(e?.message ?? "Retry failed.");
      setLoading(false);
    }
  }

  async function goCheckout(mode: "order" | "retry") {
    setUiMsg(null);

    if (mode === "order" && status !== "paid" && !filament) {
      setUiMsg("Please choose a filament color before paying.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId,
          mode,
          filament, // backend will store it
        }),
      });

      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json?.url) {
        setUiMsg(json?.error ?? "Could not start checkout.");
        setLoading(false);
        return;
      }

      window.location.href = String(json.url);
    } catch (e: any) {
      setUiMsg(e?.message ?? "Checkout failed.");
      setLoading(false);
    }
  }

  function toggle3D() {
    const next = !show3D;
    setShow3D(next);
    if (next) {
      requestAnimationFrame(() => {
        viewerTopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }
  }

  const showFilamentChooser = (status === "preview_ready" || status === "paid") && !!clayPreviewUrl;

  return (
    <div className="mt-5 space-y-4">
      {/* Status + actions */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-semibold text-slate-900">Status: {statusText}</p>
          {stageLabel ? <p className="text-xs text-slate-600">Stage: {stageLabel}</p> : null}
        </div>

        <div className="mt-2 text-sm text-slate-600">
          Attempts used: <span className="font-semibold text-slate-900">{attempts}</span>
          {freeRemaining > 0 ? (
            <>
              {" "}
              • Free remaining: <span className="font-semibold text-slate-900">{freeRemaining}</span>
            </>
          ) : (
            <>
              {" "}
              • Retry credits: <span className="font-semibold text-slate-900">{credits}</span>
            </>
          )}
        </div>

        {status === "processing" ? (
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>Progress: …</span>
              <span>{elapsedSec}s elapsed</span>
            </div>

            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
              <div className="h-full rounded-full bg-slate-900" style={{ width: `${clamp(8, 3, 99)}%` }} />
            </div>

            {message ? <p className="mt-2 text-xs text-slate-500">{message}</p> : null}
          </div>
        ) : null}

        {uiMsg ? (
          <p className="mt-3 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
            {uiMsg}
          </p>
        ) : null}

        <div className="mt-4 flex flex-wrap gap-3">
          <button
            type="button"
            disabled={loading || !canRetry}
            onClick={retry}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-sm hover:bg-slate-50 disabled:opacity-60"
          >
            {freeRemaining > 0 ? "Retry (free)" : credits > 0 ? "Retry (uses credit)" : "Retry"}
          </button>

          <button
            type="button"
            disabled={loading}
            onClick={() => goCheckout("retry")}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-sm hover:bg-slate-50 disabled:opacity-60"
          >
            Buy extra generation (€2.99)
          </button>

          <button
            type="button"
            disabled={loading || !canPay}
            onClick={() => goCheckout("order")}
            className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-slate-800 disabled:opacity-60"
            title={status !== "paid" && !filament ? "Choose a filament color before paying" : ""}
          >
            Approve &amp; pay
          </button>

          <button
            type="button"
            disabled={!canShow3D}
            onClick={toggle3D}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-sm hover:bg-slate-50 disabled:opacity-60"
            title={!canShow3D ? "3D is available after payment" : ""}
          >
            {show3D ? "Hide 3D preview" : "Show 3D preview"}
          </button>
        </div>
      </div>

      {/* 3D preview above image */}
      <div ref={viewerTopRef} />

      {show3D ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <p className="text-sm font-semibold text-slate-900">3D preview</p>
          <p className="mt-1 text-xs text-slate-600">
            3D generation starts after payment. This preview is for checking the result.
          </p>

          <div className="mt-4">
            {!modelGlbUrl ? (
              <p className="text-sm text-slate-600">3D model not ready yet.</p>
            ) : !mounted ? (
              <p className="text-sm text-slate-600">Loading 3D viewer…</p>
            ) : (
              <model-viewer
                src={modelGlbUrl}
                camera-controls
                auto-rotate
                exposure="1"
                shadow-intensity="1"
                style={{ width: "100%", height: 420, background: "white", borderRadius: 16 }}
              />
            )}
          </div>

          <div style={{ display: "none" }}>{modelObjUrl ?? ""}</div>
        </div>
      ) : null}

      {/* Preview image */}
      {clayPreviewUrl ? (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
          <img src={clayPreviewUrl} alt="Your preview" className="w-full" />
        </div>
      ) : null}

      {/* Filament chooser + pay button BELOW (no more scrolling up) */}
      {showFilamentChooser ? (
        <div className="space-y-3">
          <FilamentSelector value={filament} onChange={setFilament} disabled={loading || status === "paid"} />

          <div className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                disabled={loading || !canPay}
                onClick={() => goCheckout("order")}
                className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-slate-800 disabled:opacity-60"
                title={status !== "paid" && !filament ? "Choose a filament color before paying" : ""}
              >
                Approve &amp; pay
              </button>

              <button
                type="button"
                disabled={loading}
                onClick={() => goCheckout("retry")}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-sm hover:bg-slate-50 disabled:opacity-60"
              >
                Buy extra generation (€2.99)
              </button>
            </div>

            {status !== "paid" && !filament ? (
              <p className="mt-2 text-xs text-amber-700">
                Please select a filament color to enable “Approve &amp; pay”.
              </p>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}
