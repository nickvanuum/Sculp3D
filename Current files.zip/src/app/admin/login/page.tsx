"use client";

import { useState } from "react";
import { MuseumShell } from "@/components/museum/MuseumShell";
import { TopNav } from "@/components/museum/TopNav";
import { Card, CardTitle, CardSubtitle } from "@/components/museum/Card";

export default function AdminLoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Placeholder authentication
    if (username === "admin" && password === "password") {
      alert("Login successful!");
    } else {
      setError("Invalid credentials");
    }
  };

  return (
    <MuseumShell>
      <TopNav rightLabel="Admin" />

      <section className="mx-auto max-w-6xl px-6 pb-14 pt-6">
        <div className="mx-auto max-w-2xl">
          <Card>
            <CardTitle>Admin login</CardTitle>
            <CardSubtitle>Internal access only.</CardSubtitle>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-white/85">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="mt-1 block w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/35 shadow-[0_0_0_1px_rgba(168,85,247,0.08)] focus:border-[rgba(168,85,247,0.55)] focus:bg-white/7"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-white/85">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="mt-1 block w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/35 shadow-[0_0_0_1px_rgba(168,85,247,0.08)] focus:border-[rgba(168,85,247,0.55)] focus:bg-white/7"
                />
              </div>

              {error ? <p className="text-sm text-rose-200">{error}</p> : null}

              <button
                type="submit"
                className="w-full rounded-2xl bg-gradient-to-r from-[rgba(168,85,247,0.95)] to-[rgba(236,72,153,0.75)] px-5 py-3 text-sm font-semibold text-black shadow-[0_0_0_1px_rgba(255,255,255,0.10),0_18px_50px_rgba(168,85,247,0.35)] hover:brightness-110"
              >
                Sign in
              </button>
            </form>
          </Card>
        </div>
      </section>
    </MuseumShell>
  );
}
