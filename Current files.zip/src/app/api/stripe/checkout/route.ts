// src/app/api/stripe/checkout/route.ts
export const runtime = "nodejs";

import { NextResponse } from "next/server";
import Stripe from "stripe";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20" as any,
});

type Body = {
  orderId: string;
  mode: "order" | "retry";
  filament?: string | null; // "marble_white" | "stone_gray" | "wood_tone"
};

function getOriginFromRequest(req: Request) {
  // Works for ngrok / proxies / local dev.
  // Prefer explicit Origin if provided.
  const origin = req.headers.get("origin");
  if (origin && origin.startsWith("http")) return origin;

  // Fallback: reconstruct from forwarded headers
  const proto =
    req.headers.get("x-forwarded-proto") ||
    (process.env.NODE_ENV === "production" ? "https" : "http");

  const host =
    req.headers.get("x-forwarded-host") ||
    req.headers.get("host");

  if (host) return `${proto}://${host}`;

  // Final fallback: env or localhost
  return process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
}

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as Partial<Body>;

    if (!body?.orderId) {
      return NextResponse.json({ error: "Missing orderId" }, { status: 400 });
    }
    if (body.mode !== "order" && body.mode !== "retry") {
      return NextResponse.json({ error: "Invalid mode" }, { status: 400 });
    }

    // Load order (NOTE: uses bust_height_mm, not size_mm)
    const { data: order, error: loadErr } = await supabaseAdmin
      .from("orders")
      .select("id,status,bust_height_mm,price_cents,filament_color")
      .eq("id", body.orderId)
      .single();

    if (loadErr || !order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    // Persist filament choice if provided
    const incomingFilament =
      typeof body.filament === "string" && body.filament.trim()
        ? body.filament.trim()
        : null;

    if (incomingFilament) {
      await supabaseAdmin
        .from("orders")
        .update({ filament_color: incomingFilament })
        .eq("id", body.orderId);
    }

    const filamentForOrder = incomingFilament || (order as any).filament_color || null;

    // Require filament + price for main order payment
    if (body.mode === "order") {
      if (!filamentForOrder) {
        return NextResponse.json(
          { error: "Please choose a filament color before paying." },
          { status: 400 }
        );
      }
      const priceCents = Number((order as any).price_cents ?? 0);
      if (!Number.isFinite(priceCents) || priceCents <= 0) {
        return NextResponse.json(
          { error: "Order pricing missing. Please recreate the order." },
          { status: 400 }
        );
      }
    }

    const origin = getOriginFromRequest(req);
    const success_url = `${origin}/order/${encodeURIComponent(body.orderId)}?paid=1`;
    const cancel_url = `${origin}/order/${encodeURIComponent(body.orderId)}?canceled=1`;

    const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] =
      body.mode === "retry"
        ? [
            {
              price_data: {
                currency: "eur",
                unit_amount: 299, // €2.99
                product_data: {
                  name: "Extra generation",
                  description: "Buy an extra preview generation",
                },
              },
              quantity: 1,
            },
          ]
        : [
            {
              price_data: {
                currency: "eur",
                unit_amount: Number((order as any).price_cents),
                product_data: {
                  name: `Sculp3D bust (${Number((order as any).bust_height_mm)}mm)`,
                  description: `Custom bust generation + 3D printing service (${filamentForOrder})`,
                },
              },
              quantity: 1,
            },
          ];

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      metadata: {
        orderId: String((order as any).id),
        mode: String(body.mode),
        bust_height_mm: String((order as any).bust_height_mm ?? ""),
        filament: String(filamentForOrder ?? ""),
      },
      success_url,
      cancel_url,
    });

    return NextResponse.json({ url: session.url });
  } catch (err: any) {
    return NextResponse.json(
      {
        error: err?.message ?? "Stripe checkout failed",
        details: err?.raw?.message ?? null,
      },
      { status: 500 }
    );
  }
}
