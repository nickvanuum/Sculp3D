import { NextResponse } from "next/server";
import Stripe from "stripe";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20" as any,
});

export const runtime = "nodejs";

// Same schema-safe storage helper as checkout route
async function persistFilament(orderId: string, filament: string) {
  const clean = String(filament).trim().slice(0, 50);
  if (!clean) return;

  const a = await supabaseAdmin.from("orders").update({ filament_color: clean }).eq("id", orderId);
  if (!a.error) return;

  const b = await supabaseAdmin.from("orders").update({ filament: clean }).eq("id", orderId);
  if (!b.error) return;

  console.warn("Could not persist filament on order (webhook):", { a: a.error?.message, b: b.error?.message });
}

export async function POST(req: Request) {
  try {
    const sig = req.headers.get("stripe-signature");
    const secret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!sig || !secret) {
      return NextResponse.json({ error: "Missing Stripe signature or STRIPE_WEBHOOK_SECRET" }, { status: 400 });
    }

    const rawBody = await req.text();

    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(rawBody, sig, secret);
    } catch (err: any) {
      console.error("Webhook signature verify failed:", err?.message);
      return NextResponse.json({ error: "Webhook signature verification failed" }, { status: 400 });
    }

    // Only care about completed checkout sessions
    if (event.type !== "checkout.session.completed") {
      return NextResponse.json({ received: true });
    }

    const session = event.data.object as Stripe.Checkout.Session;
    const meta = (session.metadata || {}) as Record<string, string>;
    const orderId = meta.orderId;
    const checkoutMode = meta.checkoutMode; // "order" | "retry"
    const filament = meta.filament; // <— NEW

    if (!orderId) return NextResponse.json({ received: true });

    // Fetch order (minimal fields to avoid schema errors)
    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("id,status,retry_credits")
      .eq("id", orderId)
      .single();

    if (!order) return NextResponse.json({ received: true });

    // If it was the main order payment:
    if (checkoutMode === "order") {
      // Persist filament if present
      if (filament) await persistFilament(orderId, filament);

      await supabaseAdmin
        .from("orders")
        .update({
          status: "paid",
          stripe_payment_intent_id: (session.payment_intent as string) ?? null,
          last_stripe_event_id: event.id,
        })
        .eq("id", orderId);

      return NextResponse.json({ received: true });
    }

    // If it was a retry purchase:
    if (checkoutMode === "retry") {
      const currentCredits = Number(order.retry_credits ?? 0);

      // Persist filament if present (not required, but harmless)
      if (filament) await persistFilament(orderId, filament);

      await supabaseAdmin
        .from("orders")
        .update({
          retry_credits: currentCredits + 1,
          last_retry_paid_at: new Date().toISOString(),
          last_stripe_event_id: event.id,
        })
        .eq("id", orderId);

      return NextResponse.json({ received: true });
    }

    return NextResponse.json({ received: true });
  } catch (err: any) {
    console.error("Webhook error:", err);
    return NextResponse.json({ error: err?.message ?? "Webhook failed" }, { status: 500 });
  }
}
