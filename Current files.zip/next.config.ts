// next.config.ts
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // If you use ngrok during dev, keep this on.
  // It prevents Next from complaining about cross-origin dev requests.
  allowedDevOrigins: [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://10.0.2.2:3000", // Android emulator
    "https://*.ngrok-free.dev",
    "https://*.ngrok.app",
  ],

  // Optional but often helpful when you embed external assets / images
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**.supabase.co",
      },
      {
        protocol: "https",
        hostname: "ncybccgmvhxdwzwqhmda.supabase.co",
      },
    ],
  },

  // Keep builds clean unless you intentionally want TS errors to fail builds
  // (Recommended: keep false in production. During dev it doesn't matter.)
  typescript: {
    ignoreBuildErrors: false,
  },

  eslint: {
    ignoreDuringBuilds: false,
  },
};

export default nextConfig;
